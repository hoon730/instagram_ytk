import React from "react";
import styled from "styled-components";

const LiText = styled.li``;

const FooterListText = ({ text }) => {
  return <LiText>{text}</LiText>;
};

export default FooterListText;
