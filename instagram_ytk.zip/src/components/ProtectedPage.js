import React from "react";

// const ProtectedPage = ({ children }: { children: React.Node }) => {
//   return children;
// };
